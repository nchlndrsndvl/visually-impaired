
#!/usr/bin/env python3
"""
gps_test.py — Simple GPS tester for Raspberry Pi (or any Linux) via UART/USB

Features:
- Reads NMEA sentences from a GPS module on a serial port (default: /dev/serial0, 9600 baud)
- Parses RMC, GGA, and GSA to show: fix status, lat/lon (decimal deg), speed (km/h), sats, HDOP, altitude
- Optional CSV logging
- Minimal dependency: pyserial only (pip install pyserial)

Quick start (Raspberry Pi 3/4):
  1) Wiring (typical NEO-6M/BN-220 GPS):
     - GPS VCC -> 5V (or 3V3 if your module requires 3.3V; most common boards accept 3–5V input)
     - GPS GND -> GND
     - GPS TX  -> Pi RXD (GPIO15, BCM14)
     - (Optional) GPS RX -> Pi TXD (GPIO14, BCM15) — used only for sending config to the GPS
  2) Enable UART:
     - sudo raspi-config  → Interface Options → Serial Port → "Login shell over serial?" NO; "Enable serial port hardware?" YES → Reboot
  3) Run:
     - python3 gps_test.py --port /dev/serial0 --baud 9600
     - Add --csv out.csv to save readings.

Notes:
- If you get a permissions error opening the port: run with sudo, or add your user to 'dialout':
    sudo usermod -a -G dialout $USER && newgrp dialout
- Indoors, GPS may take minutes to lock (or never). Test near a window or outdoors with clear sky.
"""

import argparse
import csv
import sys
import time
from datetime import datetime
try:
    import serial  # pyserial
except Exception as e:
    print("ERROR: pyserial not installed. Install with: pip install pyserial", file=sys.stderr)
    raise

def nmea_latlon_to_dd(val: str, hemi: str) -> float | None:
    """Convert NMEA lat/long format (ddmm.mmmm / dddmm.mmmm) + hemisphere to decimal degrees."""
    try:
        if not val or not hemi or val == '':
            return None
        # Split into degrees and minutes
        if '.' not in val:
            return None
        dot_idx = val.find('.')
        # Minutes are the 2 digits before the dot and everything after
        # Degrees are what's left at the front (2 for lat, 3 for lon). Detect dynamically:
        deg_len = 2 if len(val[:dot_idx]) in (4,5) else max(2, len(val[:dot_idx]) - 2)
        degrees = float(val[:deg_len])
        minutes = float(val[deg_len:])
        dd = degrees + minutes / 60.0
        if hemi.upper() in ('S', 'W'):
            dd = -dd
        return dd
    except Exception:
        return None

class GpsState:
    def __init__(self):
        self.fix_ok = False
        self.fix_quality = 0      # from GGA (0 no fix, 1 GPS, 2 DGPS, etc.)
        self.fix_dim = None       # from GSA (1=no, 2=2D, 3=3D)
        self.lat = None
        self.lon = None
        self.speed_kph = None
        self.sats = None
        self.hdop = None
        self.alt_m = None
        self.last_rmc_time = None # UTC datetime from RMC if available

    def summary(self) -> str:
        latlon = "lat: ---, lon: ---"
        if self.lat is not None and self.lon is not None:
            latlon = f"lat: {self.lat:.6f}, lon: {self.lon:.6f}"
        spd = f"{self.speed_kph:.1f} km/h" if self.speed_kph is not None else "-- km/h"
        sats = f"{self.sats}" if self.sats is not None else "--"
        hdop = f"{self.hdop}" if self.hdop is not None else "--"
        alt  = f"{self.alt_m:.1f} m" if self.alt_m is not None else "-- m"
        fixq = {0: "NO", 1: "GPS", 2: "DGPS", 4: "RTK"} .get(self.fix_quality, str(self.fix_quality))
        dim  = {None: "?", 1: "NO", 2: "2D", 3: "3D"} .get(self.fix_dim, "?")
        time_str = self.last_rmc_time.strftime("%Y-%m-%d %H:%M:%S UTC") if self.last_rmc_time else "--"
        status = "LOCK" if self.fix_ok else "SEARCHING"
        return f"[{status}] {latlon} | speed: {spd} | sats: {sats} | HDOP: {hdop} | alt: {alt} | fixQ:{fixq} dim:{dim} | time: {time_str}"

def parse_rmc(fields: list[str], state: GpsState):
    # RMC: $GxRMC,1=hhmmss.sss,2=Status(A/V),3=lat,4=N/S,5=lon,6=E/W,7=speed(knots),8=track,9=date(ddmmyy),...
    try:
        status = fields[2].upper() if len(fields) > 2 else 'V'
        if status == 'A':
            lat = nmea_latlon_to_dd(fields[3], fields[4])
            lon = nmea_latlon_to_dd(fields[5], fields[6])
            state.lat = lat if lat is not None else state.lat
            state.lon = lon if lon is not None else state.lon
            # speed in knots -> km/h
            if len(fields) > 7 and fields[7] != '':
                try:
                    state.speed_kph = float(fields[7]) * 1.852
                except Exception:
                    pass
            # parse time+date to datetime UTC
            if len(fields) > 1 and len(fields) > 9 and fields[1] and fields[9]:
                t = fields[1]  # hhmmss.sss
                d = fields[9]  # ddmmyy
                try:
                    hh = int(t[0:2]); mm = int(t[2:4]); ss = int(t[4:6])
                    dd = int(d[0:2]); mo = int(d[2:4]); yy = int(d[4:6])
                    # yy 00-79 => 2000-2079, 80-99 => 1980-1999 (common NMEA convention)
                    year = 2000 + yy if yy <= 79 else 1900 + yy
                    state.last_rmc_time = datetime(year, mo, dd, hh, mm, ss)
                except Exception:
                    pass
            state.fix_ok = True
        else:
            # invalid status; do not mark fix ok
            pass
    except Exception:
        pass

def parse_gga(fields: list[str], state: GpsState):
    # GGA: $GxGGA,1=hhmmss,2=lat,3=N/S,4=lon,5=E/W,6=fixQ,7=sats,8=HDOP,9=alt,10=M,...
    try:
        if len(fields) > 6 and fields[6] != '':
            try:
                state.fix_quality = int(fields[6])
            except Exception:
                pass
            state.fix_ok = state.fix_ok or (state.fix_quality > 0)
        if len(fields) > 7 and fields[7] != '':
            try:
                state.sats = int(fields[7])
            except Exception:
                pass
        if len(fields) > 8 and fields[8] != '':
            state.hdop = fields[8]
        if len(fields) > 9 and fields[9] != '':
            try:
                state.alt_m = float(fields[9])
            except Exception:
                pass
        # update lat/lon if present
        lat = nmea_latlon_to_dd(fields[2] if len(fields) > 2 else '', fields[3] if len(fields) > 3 else '')
        lon = nmea_latlon_to_dd(fields[4] if len(fields) > 4 else '', fields[5] if len(fields) > 5 else '')
        state.lat = lat if lat is not None else state.lat
        state.lon = lon if lon is not None else state.lon
    except Exception:
        pass

def parse_gsa(fields: list[str], state: GpsState):
    # GSA: $GxGSA,1=mode(M/A),2=fix(1=no,2=2D,3=3D),...,15=PDOP,16=HDOP,17=VDOP
    try:
        if len(fields) > 2 and fields[2] != '':
            try:
                state.fix_dim = int(fields[2])
                state.fix_ok = state.fix_ok or (state.fix_dim in (2,3))
            except Exception:
                pass
        if len(fields) > 16 and fields[16] != '':
            state.hdop = fields[16]
    except Exception:
        pass

def main():
    ap = argparse.ArgumentParser(description="Simple GPS tester (NMEA over serial).")
    ap.add_argument("--port", default="/dev/serial0", help="Serial port (e.g., /dev/serial0, /dev/ttyAMA0, /dev/ttyUSB0)")
    ap.add_argument("--baud", type=int, default=9600, help="Baud rate (default 9600)")
    ap.add_argument("--csv", default=None, help="Optional CSV log file path")
    ap.add_argument("--raw", action="store_true", help="Also print raw NMEA lines")
    ap.add_argument("--no-color", action="store_true", help="Disable ANSI colors")
    args = ap.parse_args()

    try:
        ser = serial.Serial(args.port, args.baud, timeout=1)
    except Exception as e:
        print(f"ERROR opening serial port {args.port} @ {args.baud}: {e}", file=sys.stderr)
        print("Hints: check wiring, ensure UART is enabled, try sudo, or use a different port like /dev/ttyUSB0.", file=sys.stderr)
        sys.exit(1)

    state = GpsState()
    csv_writer = None
    csv_file = None
    if args.csv:
        try:
            csv_file = open(args.csv, "w", newline="")
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(["timestamp_utc", "lat", "lon", "speed_kph", "sats", "hdop", "alt_m", "fix_quality", "fix_dim"])
        except Exception as e:
            print(f"WARNING: Cannot open CSV file {args.csv}: {e}", file=sys.stderr)
            csv_writer = None

    def colorize(s, color):
        if args.no_color:
            return s
        colors = {
            "red": "\033[31m",
            "green": "\033[32m",
            "yellow": "\033[33m",
            "cyan": "\033[36m",
            "reset": "\033[0m",
        }
        return colors.get(color, "") + s + colors["reset"]

    last_print = 0.0
    print("Reading NMEA… Press Ctrl+C to exit.")
    try:
        while True:
            line = ser.readline().decode("ascii", errors="ignore").strip()
            if not line:
                # print periodically even if no fresh lines
                pass
            else:
                if args.raw:
                    print(line)
                if line.startswith("$") and "*" in line:
                    # Strip checksum for splitting
                    core = line[1: line.find("*")]
                    parts = core.split(",")
                    if len(parts) > 0:
                        talker_and_type = parts[0]  # e.g., GPRMC
                        # The first field in 'fields' is the sentence type itself (like GPRMC)
                        fields = [None] + parts  # pad to match indexes used above
                        if talker_and_type.endswith("RMC"):
                            parse_rmc(fields, state)
                        elif talker_and_type.endswith("GGA"):
                            parse_gga(fields, state)
                        elif talker_and_type.endswith("GSA"):
                            parse_gsa(fields, state)

            now = time.time()
            if now - last_print >= 1.0:
                last_print = now
                text = state.summary()
                # Colorize based on lock
                if state.fix_ok:
                    print(colorize(text, "green"))
                else:
                    print(colorize(text, "yellow"))

                if csv_writer:
                    csv_writer.writerow([
                        datetime.utcnow().isoformat(timespec="seconds") + "Z",
                        f"{state.lat:.6f}" if state.lat is not None else "",
                        f"{state.lon:.6f}" if state.lon is not None else "",
                        f"{state.speed_kph:.2f}" if state.speed_kph is not None else "",
                        state.sats if state.sats is not None else "",
                        state.hdop if state.hdop is not None else "",
                        f"{state.alt_m:.2f}" if state.alt_m is not None else "",
                        state.fix_quality,
                        state.fix_dim if state.fix_dim is not None else ""
                    ])
                    # Flush occasionally to persist
                    csv_file.flush()
    except KeyboardInterrupt:
        print("\nExiting…")
    finally:
        try:
            ser.close()
        except Exception:
            pass
        if csv_file:
            csv_file.close()

if __name__ == "__main__":
    main()
