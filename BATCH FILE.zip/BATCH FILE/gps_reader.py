#!/usr/bin/env python3
"""
gps_reader.py — Raspberry Pi 3B NMEA reader akin to the TinyGPS++ Arduino sketch.

Prints once per second:
Fix?  Sats  HDOP  Lat       Lon       Alt(m)  Speed(km/h)

Usage:
  python3 gps_reader.py --port /dev/serial0 --baud 9600
"""

import argparse
import sys
import time
from typing import Optional

import serial
import pynmea2


class NMEAState:
    """Holds latest parsed values from the stream."""
    def __init__(self):
        self.has_fix: Optional[bool] = None
        self.sats: Optional[int] = None
        self.hdop: Optional[float] = None
        self.lat: Optional[float] = None
        self.lon: Optional[float] = None
        self.alt_m: Optional[float] = None
        self.speed_kmh: Optional[float] = None
        # Internals for determining fix
        self._fix_quality: Optional[int] = None  # from GGA gps_qual
        self._rmc_status: Optional[str] = None   # 'A' valid, 'V' void

    def update_from_msg(self, msg):
        try:
            # GGA: fix quality, num satellites, HDOP, altitude, lat/lon
            if isinstance(msg, pynmea2.types.talker.GGA):
                # Decimal degrees via .latitude/.longitude properties
                if hasattr(msg, "latitude") and hasattr(msg, "longitude"):
                    if msg.latitude != "" and msg.longitude != "":
                        self.lat = float(msg.latitude)
                        self.lon = float(msg.longitude)
                # Satellites and HDOP
                if msg.num_sats:
                    self.sats = int(msg.num_sats)
                if msg.horizontal_dil:
                    self.hdop = float(msg.horizontal_dil)
                # Altitude (meters)
                if msg.altitude:
                    self.alt_m = float(msg.altitude)
                # Fix quality: 0=no fix; 1=GPS fix; 2=DGPS; 4=RTK; etc.
                try:
                    self._fix_quality = int(msg.gps_qual)
                except Exception:
                    pass

            # RMC: status (A/V), lat/lon, speed over ground (knots)
            elif isinstance(msg, pynmea2.types.talker.RMC):
                self._rmc_status = getattr(msg, "status", None)
                if hasattr(msg, "latitude") and hasattr(msg, "longitude"):
                    if msg.latitude != "" and msg.longitude != "":
                        self.lat = float(msg.latitude)
                        self.lon = float(msg.longitude)
                # knots → km/h
                sog_knots = msg.spd_over_grnd or ""
                if sog_knots != "":
                    try:
                        self.speed_kmh = float(sog_knots) * 1.852
                    except Exception:
                        pass

            # GSA: DOP values often more reliable here
            elif isinstance(msg, pynmea2.types.talker.GSA):
                if msg.hdop:
                    try:
                        self.hdop = float(msg.hdop)
                    except Exception:
                        pass

            # Some receivers report satellites-in-view via GSV; we prefer GGA's num_sats (used)
            # so we don't force-update sats here.

        except Exception:
            # Ignore malformed bits
            pass

        # Determine has_fix similar to TinyGPS++ logic
        has_gga_fix = (self._fix_quality is not None and self._fix_quality > 0)
        has_rmc_fix = (self._rmc_status == "A")
        self.has_fix = bool(has_gga_fix or has_rmc_fix)


def detect_port(preferred: Optional[str]) -> str:
    """Pick a likely serial port if none provided."""
    if preferred:
        return preferred
    # Common candidates on Pi/USB
    for cand in ("/dev/serial0", "/dev/ttyAMA0", "/dev/ttyS0", "/dev/ttyUSB0", "/dev/ttyACM0"):
        try:
            with serial.Serial(cand, 9600, timeout=0.1) as _:
                return cand
        except Exception:
            continue
    # Fallback
    return "/dev/serial0"


def open_serial(port: str, baud: int) -> serial.Serial:
    return serial.Serial(
        port=port,
        baudrate=baud,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=0.5,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", default=None, help="Serial port (e.g., /dev/serial0)")
    ap.add_argument("--baud", type=int, default=9600, help="Baud rate (default 9600)")
    args = ap.parse_args()

    port = detect_port(args.port)
    baud = args.baud

    print(f"PyGPS status @{baud} (port={port})")
    print("Fields: Fix?  Sats  HDOP  Lat       Lon       Alt(m)  Speed(km/h)")

    try:
        ser = open_serial(port, baud)
    except Exception as e:
        print(f"ERROR: cannot open {port} @ {baud}: {e}", file=sys.stderr)
        sys.exit(1)

    state = NMEAState()
    last_print = 0.0
    buffer = b""

    try:
        while True:
            chunk = ser.read(1024)
            if chunk:
                buffer += chunk
                # Split by newline; keep last partial line in buffer
                lines = buffer.split(b"\n")
                buffer = lines[-1]  # remainder
                for raw in lines[:-1]:
                    line = raw.strip().decode("ascii", errors="ignore")
                    if not line.startswith("$"):
                        continue
                    try:
                        msg = pynmea2.parse(line, check=True)
                        state.update_from_msg(msg)
                    except Exception:
                        # ignore badly formed sentences
                        pass

            now = time.monotonic()
            if now - last_print >= 1.0:
                last_print = now

                has_fix = bool(state.has_fix)
                sats = state.sats if state.sats is not None else 0
                hdop = state.hdop if state.hdop is not None else 0.0
                lat = state.lat
                lon = state.lon
                alt = state.alt_m if state.alt_m is not None else 0.0
                spd = state.speed_kmh if state.speed_kmh is not None else 0.0

                lat_str = f"{lat:.6f}" if lat is not None else "----"
                lon_str = f"{lon:.6f}" if lon is not None else "----"

                # Match the Arduino-style feel (spacing kept simple)
                yesno = "YES " if has_fix else "NO  "
                print(
                    f"{yesno} "
                    f"{sats:>2}   "
                    f"{hdop:>4.2f}   "
                    f"{lat_str:<10}  "
                    f"{lon_str:<10}  "
                    f"{alt:>6.1f}    "
                    f"{spd:>5.1f}"
                )
    except KeyboardInterrupt:
        print("\nExiting.")
    finally:
        try:
            ser.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
